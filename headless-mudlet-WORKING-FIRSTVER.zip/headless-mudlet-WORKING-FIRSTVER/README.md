
# mudlet-headless (Real Source Release)

## Build

```bash
mkdir build
cd build
cmake ..
make
```

## Run

```bash
./mudlet-headless
```
